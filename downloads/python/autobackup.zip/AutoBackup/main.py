import os

os.system("cls")

print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+----------                           +
|      Starting...                    |
| importing modules...                |
|                                     |
+-------------------------------------+""", end="")

import os.path
import shutil
from shutil import copyfile
import concurrent.futures
from colorit import *
import datetime
import random
import time

try:
    import psutil
except ImportError:
    os.system("@echo off")
    os.system("pip install psutil")

print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+-------------------                  +
|      Starting...                    |
| Writing functions...                |
|                                     |
+-------------------------------------+""", end="")


def get_size(start_path='.'):
    """
    :param start_path: the path to measure the size
    :return: none
    """
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)

    return total_size


def copytree(src, dst, symlinks=False, ignore=None):
    for item in os.listdir(src):
        print(f"BACKUP: {item}                        \r", end="")
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks, ignore)
        else:
            shutil.copy2(s, d)


def backup_file(src, dst):
    """
    :param src: the file to copy/ backup
    :param dst: the location to copy the file to
    :return: none
    """
    if os.path.isdir(src):
        copytree(src, dst)
    else:
        print(f"BACKUP: {src}                     \r", end="")
        with open(src, "w"):
            pass
        copyfile(src, dst)


def show_bar(items: list):
    """
    :param items: a list integers of all the items to index
    :return: the bar as a string
    """

    COLORS = [(0, 255, 0), (255, 0, 0), (0, 0, 255), (255, 255, 0), (0, 255, 255), (255, 127, 0), (0, 255, 127)]

    final_str = "["
    total_count = 0
    counter = 0

    for item in items:
        total_count += item

    for item in items:
        final_str += color_back(" " * round((item / total_count) * 100), COLORS[counter][0], COLORS[counter][1],
                                COLORS[counter][2])
        counter += 1

        if counter == 6:
            counter = 0

    final_str += "]"
    return final_str


print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+------------------------             +
|      Starting...                    |
| Declaring variables                 |
|                                     |
+-------------------------------------+""", end="")

VERSION = "ALPHA"
COLORS = [(0, 255, 0), (255, 0, 0), (0, 0, 255), (255, 255, 0), (0, 255, 255), (255, 127, 0)]

print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+---------------------------          +
|      Starting...                    |
| Reading:                            |
| backup.txt                          |
+-------------------------------------+""", end="")

current_dir = os.getcwd()
os.chdir(current_dir)
with open("backup.txt", "r") as f:
    files_to_backup = f.read().split("\n")


print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+---------------------------------    +
|      Starting...                    |
| Reading:                            |
| config.txt                          |
+-------------------------------------+""", end="")

with open("config.txt", "r") as f:
    backup_path = f.read().split("\n")[0]


print("""\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r

+-------------------------------------+
|  BACKUP alpha                       |
+-------------------------------------+
|      Finishing...                   |
|                                     |
|                                     |
+-------------------------------------+""", end="")

os.system("cls")
os.system(f"title Backup {VERSION}")

try:
    while True:
        print(f"_________Backup {VERSION}_________")
        print("Please select an option\n")

        print("""1: show backup list
2: Add files to backup list
""" + color_front("3: Backup now", 0, 255, 0) + """
4: Setup backup schedule
5: Set backup target
6: Settings

""" + color_front("7: Exit", 255, 0, 0))

        answer = input("Enter an option> ")

        os.system("cls")

        if "1" in answer:
            print("BACKUP FILES")

            with open("backup.txt", "r") as f:
                files_to_backup = f.read().split("\n")

            with open("config.txt", "r") as f:
                backup_dest = f.read().split("\n")[0]

            if "r" not in answer:
                try:
                    estimated_file_size = 0
                    loops = 0
                    total_file_size = []

                    for i, file in enumerate(files_to_backup):
                        if os.path.isdir(file):
                            filesize = get_size(file)
                            total_file_size.append(filesize)
                            print(color_front(f"DIR : {file} ".ljust(80) + f"({filesize:,} Bytes)", COLORS[i - (loops
                                              * 6)][0], COLORS[i - (loops * 6)][1], COLORS[i - (loops * 6)][2]))
                            estimated_file_size += get_size(file)
                        else:
                            filesize = os.path.getsize(file)
                            total_file_size.append(filesize)
                            print(color_front(f"FILE: {file} ".ljust(80) + f"({filesize:,} Bytes)", COLORS[i - (loops
                                              * 6)][0], COLORS[i - (loops * 6)][1], COLORS[i - (loops * 6)][2]))
                            estimated_file_size += os.path.getsize(file)

                        if i % 5 == 0:
                            loops += 1

                    with open("config.txt", "r") as f:
                        bytes_per_second = f.read().split("\n")[1]

                    print(f"Sizes: {show_bar(total_file_size)}")
                    print(f"\nBackup path: {backup_dest}")

                    print(f"Estimated backup time: {round(estimated_file_size / int(bytes_per_second))}s")
                    print(f"\nEstimated backup size: {estimated_file_size:,} Bytes", end="")
                    if estimated_file_size >= 1073741824:
                        print(f" ({round(estimated_file_size / 1073741824, 1)}GB)")
                    elif estimated_file_size >= 1048576:
                        print(f" ({round(estimated_file_size / 1048576, 1)}MB)")
                    elif estimated_file_size >= 1024:
                        print(f" ({round(estimated_file_size / 1024, 1)}KB)")

                    print(f"Space remaining: {psutil.disk_usage(backup_dest).free:,} Bytes "
                          f"({100 - psutil.disk_usage(backup_dest).percent}% "
                          f"free)")
                    space_after_backup = psutil.disk_usage(backup_dest).free - estimated_file_size

                    if psutil.disk_usage(backup_dest).free - estimated_file_size > 1000000:
                        print(color_front(f"Space after backup: "
                                          f"{psutil.disk_usage(backup_dest).free - estimated_file_size:,}"
                                          f" Bytes", 0, 255, 0), end="")
                    else:
                        print(color_front(f"Space after backup: "
                                          f"{psutil.disk_usage(backup_dest).free - estimated_file_size:,}"
                                          f" Bytes", 255, 0, 0), end="")
                        print(color_front("Not enough space to backup!", 255, 0, 0))

                    if space_after_backup >= 1073741824:
                        print(f" ({round(space_after_backup / 1073741824, 1)}GB)")
                    elif space_after_backup >= 1048576:
                        print(f" ({round(space_after_backup / 1048576, 1)}MB)")
                    elif space_after_backup >= 1024:
                        print(f" ({round(space_after_backup / 1024, 1)}KB)")

                except KeyboardInterrupt:
                    print(color_front("Process aborted!", 255, 255, 0))

            else:
                print(color_front("Reduced mode!\n", 255, 128, 0))

                for file in files_to_backup:
                    print(file)

            print("\n")

        elif answer == "2":
            file = input("Please input the path to the file\n> ")

            if os.path.exists(file):
                print("Adding file...")
                with open("backup.txt", "a") as f:
                    f.write("\n" + file)
                print(color_front("File successfully added!", 0, 255, 0))
            else:
                print(color_front("File does not exist", 255, 0, 0))
                continue

        elif answer == "3":
            print("Preparing to backup...\r")

            with open("config.txt", "r") as f:
                backup_path = f.read().split("\n")[0]

            if backup_path == "":
                print(color_front("No backup path specified", 255, 0, 0))
                continue
            else:
                if "c:" in backup_path:
                    print(color_front("Warning: Specified backup path is a system directory!", 255, 127, 127))

            with open("backup.txt", "r") as f:
                files_to_backup = f.read().split("\n")

            os.chdir(backup_path)

            current_day = datetime.datetime.now().day
            current_month = datetime.datetime.now().month
            current_year = datetime.datetime.now().year
            current_hour = datetime.datetime.now().hour
            current_minute = datetime.datetime.now().minute
            current_second = datetime.datetime.now().second


            os.mkdir(f"{current_day}-{current_month}-{current_year} {current_hour} {current_minute} {current_second}")
            backup_path = backup_path + f"{current_day}-{current_month}-{current_year} {current_hour}" \
                                        f" {current_minute} {current_second}"
            os.chdir(backup_path)

            print("Backing up...")

            os.chdir(backup_path)

            current_dir = os.getcwd()
            os.chdir(current_dir)

            for i, entity in enumerate(files_to_backup):
                print(f"Backup: {entity}                  \r", end="")

                current_dir = os.getcwd()
                os.chdir(backup_path)

                os.mkdir(f"{i}")

                os.chdir(F"{i}")

                try:
                    backup_file(entity, os.getcwd())
                except PermissionError:
                    print(color_front(f"PERMISSION-ERROR: {entity}", 255, 0, 0))
                except FileNotFoundError:
                    print(color_front(f"FILE-NOT-FOUND-ERROR: {entity}", 255, 0, 0))
                except FileExistsError:
                    print(color_front(f"FILE-EXISTS-ERROR: {entity}", 255, 0, 0))
                except KeyboardInterrupt:
                    print(color_front("File/Directory skipped!", 255, 0, 0))


            current_dir = os.getcwd()
            os.chdir(current_dir)

            # with concurrent.futures.ProcessPoolExecutor() as executor:
            #     for entity in files_to_backup:
            #         executor.submit(backup_file, entity)

            os.system("cls")

            print(color_front("Backup Completed!", 0, 255, 0))

        elif answer == "4":
            print("This feature requires python file : background-task.py to be set as a background task!")
            print("You should find the file in the same directory, if not, its probably not done yet")
        elif answer == "5":
            path = input("Please enter the file path to backup files to\n> ")
            if os.path.exists(path):
                if os.path.isdir(path):
                    with open("config.txt", "r") as f:
                        prev_path = f.read().split("\n")[0]

                    if prev_path != "":
                        confirm = input(color_front(f"({prev_path}) is already in this file, would"
                                                    f" you like to overwrite this? (Y/N)\n> ", 255, 255, 0))
                    else:
                        confirm = "Y"

                    if confirm.upper() == "Y":
                        with open("config.txt", "r") as f:
                            config = f.read().split("\n")

                        with open("config.txt", "w") as f:
                            config[0] = path

                            final_str = ""
                            for i in config:
                                final_str += i + "\n"

                            f.write(final_str.strip("\n"))

                    else:
                        print(color_front("Process aborted", 255, 127, 0))
                else:
                    print(color_front("Path is not a directory", 255, 0, 0))
            else:
                print(color_front("Could not find path", 255, 0, 0))

        elif answer == "6":
            print("Loading settings...\r")

            os.chdir(".")

            with open("config.txt", "r") as f:
                config = f.read().split("\n")

            print("SETTINGS:")
            print(f"(1) Backup path: {config[0]}")
            print(f"(2) Estimated backup speed per sec: {int(config[1]):,} Bytes")

            hold = input("\nEnter a setting to change or press ENTER to save and exit settings:\n> ")

            if hold == "1":
                print("You can change this setting by typing 5 in the main menu")
            elif hold == "2":
                option = input("Would you like to do an automatic calculation or would you like to manually enter "
                               "in a number? (M/A)\n> ")

                if option.upper() == "M":
                    num = int(input("Enter the backup speed in bytes/second\n>"))
                elif option.upper() == "A":

                    if config[0] == "":
                        print(color_front("No backup path specified", 255, 0, 0))

                    else:
                        if os.path.exists("temp.txt"):
                            print("Please move / delete temp.txt as it would be used to stat the test, then restart "
                                  "the program")

                            a = input("Press ENTER key to exit and return to command prompt")
                            exit()

                        else:
                            test_size = input("Enter a test size in bytes, more = slower but more accurate (80, "
                                              "000)\n>")

                            accurate_test = input("Do you want to do an accurate test? (Y/N)")

                            if test_size == "":
                                test_size = 80000
                            else:
                                try:
                                    test_size = int(test_size)
                                except:
                                    print(color_front("Invalid number!", 255, 0, 0))
                                    continue

                            symbols = "1234567890-=qwertyuiop[]asdfghjkl;'zxcvbnm,./ !@#$%^&*()_+QWERTYUIOP{" \
                                      "}|ASDFGHJKL:\"ZXCVBNM<>"

                            final = ""
                            for i in range(0, test_size, 1 if accurate_test.upper() == "Y" else 8):
                                print(f"Generating, DO NOT CLOSE PROGRAM! ({round((i / test_size) * 100)}%) ITR: {i} "
                                      f"\r", end="")

                                final += symbols[random.randint(0, len(symbols) - 1)]* 1 if\
                                    accurate_test.upper() == "Y" else 8

                            with open("temp.txt", "w") as f:
                                print("Writing                                                ")
                                f.write("This is a temporary text file created by AutoBackup, you may delete this "
                                        "file with no harm\n\n" + final)

                            print("Copying...")

                            start_time = time.monotonic()
                            copyfile("temp.txt", config[0]+"temp.txt")
                            end_time = time.monotonic()

                            print("Removing temp files...")
                            os.remove("temp.txt")

                            print("Updating config...")
                            config[1] = str(round(test_size//(end_time-start_time)))

                            with open("config.txt", "w") as f:
                                final = ""

                                for i in config:
                                    final += i + "\n"

                                final = final.strip()
                                f.write(final)


                            os.system("cls")

                            print(f"Copy took {round(end_time-start_time, 4)}s ("
                                  f"{round(test_size//(end_time-start_time)):,} Bytes/s)")


        elif answer == "7":
            exit()
except KeyboardInterrupt:
    print(color_front("\nAction canceled by user!", 255, 255, 0))
except Exception as e:
    print(color_front(f"\nInternal error: {e}", 255, 0, 0))
    hold = input("Press ENTER to return to command prompt")
