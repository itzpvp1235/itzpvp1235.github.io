# SERVER SETTINGS ------------------------

# SERVER CONFIGURATION:

IP = "192.168.56.1"
# Set the value to "127.0.0.1" To host on the localhost system
# Otherwise, set it to your public IP address
#
# You can find your public IP address by searching "What is my IP"
# on your browser

PORT = 1234
# The port number to host the server on, if the program
# fails to run, you can try changing this number
#
# IMPORTANT NOTICE: Make sure you have the same IP and PORT
# on both the server and client.

REQUEST_TIMEOUT = 5000
# The amount of time (in milliseconds) before the server kicks a player for
# being "offline" when sending check packets

# Logging:

# Log message prefixes
PREFIX_INFO = "[Server thread/INFO]:"
# The prefix used when the server logs information

PREFIX_WARNING = "[Server warning]:"
# The prefix used when the server displays a warning

PREFIX_ERROR = "[Server error]:"
# The prefix to display when there is an error

PREFIX_GAME = "[Game thread/MAINGAME]:"
# The prefix to use when the server is logging game information

# GAME CONFIGURATION:

IDLE_TIMEOUT = 10000
# The maximum amount of time (In interactions) between packets sent to the server
# Before the server kicks the player for "Inactivity"
#
# On the default setting, clients request score data from the server every 0.5s
# Make sure that this number is at least 5x the time between data requests time set
# in client.py, otherwise, the server will kick a player if there is a bit of lag
#
# If a player is Inactive, they will be removed from the player list
# This prevents modifications of the client to prevent cheaters or clients who do not
# send the proper data necessary to the server to handle disconnects
#
# (( /!\ NOT RECOMMENDED /!\ ))
# Set this value to a high number (like 1 trillion) if you don't want to idle timeout players

MIN_PLAYERS = 2
# The above value means the minimum number of players
# required for the game to start.

FIXED_QUESTIONS = False
# Fixed questions: Provide a list of questions in the list below
# If fixed questions is False, the server will automatically generate
# a list of questions based on the settings provided below

# Manually create questions

# Format: "Question": Answer
# Please do not go over 300 questions as it nay cause the program to error
#
# The answer must be an Integer (Number)
# The Question must be a string (Alphanumerical characters)
#
# You can also do questions that are not math related, as long as the answer
# is an Integer (Number)
QUESTION_LIST = {

}
# If FIXED_QUESTIONS is False, then leave this list blank

# Automatic question generation:

NO_OF_QUESTIONS = 5
# NO_OF_QUESTIONS means the number of questions to generate, ignore these values if
# you specified to manually create questions using the FIXED_QUESTIONS mentioned above
# Please do not go above 300 questions as it may cause the program to error

MODE = "all"
# Ignore this variable if you specified to manually create questions using the
# FIXED_QUESTIONS mentioned above
#
# Currently available modes:
# sub = subtraction
# add = addition
# mul = multiplication
# div = division ( rounded answers can be specified below \/ )
#
# More modes coming soon!
#
# Use "all" to include questions from all modes
#
# If the mode is invalid or empty, the server will send a blank question list

NUMBER_RANGE_ADD_MINUS = [1, 3]
# The range of numbers the program to use when generating questions that are either
# add or subtract
# Format: [MIN, MAX]
#
# e.g. if the range is [1, 50] questions can be 50+50, 20+50, 1+25, 1+50 and so on
#
# PLEASE NOTE: Numbers above 100 000 may lag the server depending on the hardware
# you are using

NUMBER_RANGE_DIVIDE_MULTIPLY = [1, 3]
# The range of numbers the program to use when generating questions that are either
# add or subtract
# Format: [MIN, MAX]
#
# e.g. if the range is [1, 50] questions can be 50*50, 20*50, 1*25, 1*50 and so on
#
# PLEASE NOTE: Numbers above 1 000 may lag the server depending on the hardware
# you are using

MAKE_DIVISION_PERFECT_NUMBERS = True
# Make division answers a number without a decimal place
# It is recommended that you turn this on to avoid python 64 denominator conversion to

# DO NOT EDIT CODE -----------------------
# Please do not edit the code below, if you do, the program may error or malfunction

import socket
import random
import sys
import pickle
import errno
import time

DUMMY_MESSAGE = "asdfaksdfsfjskldfjsdlkfjsdf"

all_clients = []
all_addresses = []
all_usernames = []
all_usernames_scores = {}
time_since_last_packet = {}

get_more_players = False

socket.setdefaulttimeout(REQUEST_TIMEOUT)

print(f"{PREFIX_INFO} Starting server...")

try:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((IP, PORT))
except Exception as e:
    print(f"{PREFIX_ERROR}********************************************************************************************")
    print(f"{PREFIX_ERROR} A fatal exception occurred while starting the server.")
    print(F"{PREFIX_ERROR} Error: {str(e)}\n{PREFIX_ERROR}")

    print(F"{PREFIX_ERROR} ------Error information------")
    if str(e) == "[WinError 10048] Only one usage of each socket address (protocol/network address/port) is normally " \
                 "permitted":
        print(f"{PREFIX_ERROR} This port is currently being used by another application and is not available for use")
        print(f"{PREFIX_ERROR} You can try another port by changing PORT to a different number in the configuration")
    elif str(e) == "bind(): port must be 0-65535.":
        print(f"{PREFIX_ERROR} The port number is too high or too low, you can only specify ports up to the 16-bit "
              f"integer limit. (0-65535)")
        print(f"{PREFIX_ERROR} You need to use another port by changing PORT to a different number in the "
              f"configuration")
    else:
        print(f"{PREFIX_ERROR} Un unknown error occurred and needs to be fixed. Please contact the developer.")

    print(f"{PREFIX_ERROR}********************************************************************************************")
    a = input("Press ENTER to terminate application")
    sys.exit()

s.listen(10)

print(f"{PREFIX_INFO} Server started")
print(f"{PREFIX_INFO} Now listening for connections")


def get_players(num):
    global client_socket
    print(f"{PREFIX_INFO} Getting players...")

    while True:
        client_socket, address = s.accept()

        all_clients.append(client_socket)
        all_addresses.append(address)

        client_socket.setblocking(False)

        username = client_socket.recv(2048).decode("utf-8")
        if username in all_usernames:
            del all_clients[-1]
            del all_addresses[-1]
            client_socket.close()
            print(f"{PREFIX_INFO} User {username} was kicked because they use a duplicate username")
            continue

        all_usernames.append(username)

        print(f"{PREFIX_INFO} Connection from {address} has been successfully established! ({len(all_clients)})")
        print(f"{PREFIX_INFO} Setting blocking to false for client socket")

        if len(all_clients) >= num:
            print(f"{PREFIX_INFO} Players have been collected")
            print(f"{PREFIX_INFO} Connection for more players has been closed unless players disconnect.")
            break


get_players(MIN_PLAYERS)

print(f"{PREFIX_INFO} Verifying all players")

get_more_players = False
for i, client in enumerate(all_clients):
    print(f"{PREFIX_INFO} Checking player: {all_usernames[i]} IP: {all_addresses[i]}")

    try:
        client.send(DUMMY_MESSAGE.encode("utf-8"))
        client.recv(2048)

        print(f"{PREFIX_INFO} {all_addresses[i]} passed the check!")

    except ConnectionResetError as e:
        print(f"{PREFIX_WARNING}Client disconnected, removing player from player list")
        del all_clients[i]
        del all_addresses[i]
        del all_usernames[i]
        get_more_players = True

    except ConnectionRefusedError as e:
        print(f"{PREFIX_WARNING} Client refused connections, removing player from player list")
        del all_clients[i]
        del all_addresses[i]
        del all_usernames[i]
        get_more_players = True

    except ConnectionAbortedError as e:
        print(f"{PREFIX_WARNING} Client aborted connection, removing player from player list")
        del all_clients[i]
        del all_addresses[i]
        del all_usernames[i]
        get_more_players = True

    except ConnectionError as e:
        print(f"{PREFIX_WARNING} Other client error: {str(e)}, removing player from player list")
        del all_clients[i]
        del all_addresses[i]
        del all_usernames[i]
        get_more_players = True

    except IOError as e:
        if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
            print(f"{PREFIX_ERROR} Reading error: ", str(e))
            a = input("Press ENTER to terminate application")
            sys.exit()

        continue

    except Exception as e:
        print(f"{PREFIX_ERROR} General error: {str(e)}, closing all connections, shutting down server")
        a = input("Press ENTER to terminate application")
        sys.exit()

    print(f"{PREFIX_INFO} Finished checking client")


print(f"{PREFIX_INFO} Finished checking usernames")

if get_more_players:
    print(f"{PREFIX_INFO} 1 or more players disconnected from the server, opening connections again.")
    s.listen(10)
    get_players(MIN_PLAYERS)

start_time = millis = round(time.monotonic() * 1000)


print(f"{PREFIX_INFO} Starting game")
print(f"{PREFIX_INFO} Generating math questions")

math_questions = {}

if QUESTION_LIST == {} and FIXED_QUESTIONS:
    print(f"{PREFIX_ERROR} Fixed questions is set to true however there are no questions provided :(")
    a = input("Press ENTER to terminate application")
    sys.exit()

if not FIXED_QUESTIONS:
    if QUESTION_LIST != {}:
        print(f"{PREFIX_WARNING} Fixed questions is off however, there are still questions in the questions list, "
              f"ignoring it")

    for i in range(0, NO_OF_QUESTIONS):
        print(f"{PREFIX_INFO} Generating question {i+1}/{NO_OF_QUESTIONS}")

        if MODE == "all":
            operation = random.randint(1, 4)
        else:
            operation = 100000000

        if operation == 1 or MODE == "add":
            num1 = random.randint(NUMBER_RANGE_ADD_MINUS[0], NUMBER_RANGE_ADD_MINUS[1])
            num2 = random.randint(NUMBER_RANGE_ADD_MINUS[0], NUMBER_RANGE_ADD_MINUS[1])

            question = f"{num1} + {num2}"
            answer = num1 + num2

            math_questions[question] = answer

        elif operation == 2 or MODE == "sub":
            num1 = random.randint(NUMBER_RANGE_ADD_MINUS[0], NUMBER_RANGE_ADD_MINUS[1])
            num2 = random.randint(NUMBER_RANGE_ADD_MINUS[0], NUMBER_RANGE_ADD_MINUS[1])

            question = f"{num1} - {num2}"
            answer = num1 - num2

            math_questions[question] = answer

        elif operation == 3 or MODE == "mul":
            num1 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])
            num2 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])

            question = f"{num1} * {num2}"
            answer = num1 * num2

            math_questions[question] = answer

        elif operation == 4 or MODE == "div":
            num1 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])
            num2 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])

            if MAKE_DIVISION_PERFECT_NUMBERS and num1 / num2 != int(num1 / num2):
                while num1 / num2 != int(num1 / num2):
                    print(f"{PREFIX_INFO} Question #{i} (division question). Answer was not an integer, regenerating "
                          f"question...")

                    num1 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])
                    num2 = random.randint(NUMBER_RANGE_DIVIDE_MULTIPLY[0], NUMBER_RANGE_DIVIDE_MULTIPLY[1])

                question = f"{num1} / {num2}"
                answer = round(num1 / num2)

                math_questions[question] = answer

            else:
                question = f"Round {num1} / {num2}"
                answer = round(num1 / num2)

                math_questions[question] = answer

        else:
            print(f"{PREFIX_ERROR} System failed to generate question, stopping server")
            a = input("Press ENTER to terminate application")
            sys.exit()

        print(f"{PREFIX_INFO} Successfully generated question {i+1}/{NO_OF_QUESTIONS} ({((i+1)/NO_OF_QUESTIONS)*100}% "
              f"Complete)")

    print(f"{PREFIX_INFO} Successfully finished generating questions!")

else:
    print(f"{PREFIX_INFO} You have selected to create your own list of questions")
    print(f"{PREFIX_INFO} Loading questions into memory, please wait...")

    for i, key, value in enumerate(QUESTION_LIST.items()):
        print(f"{PREFIX_INFO} Loading question {i+1}")
        math_questions[key] = value
        print(f"{PREFIX_INFO} Successfully loaded question {i+1} into memory ({((i+1)/len(QUESTION_LIST))*100}% "
              f"complete)")

    print(f"{PREFIX_INFO} Successfully loaded all questions into memory!")

print(f"{PREFIX_INFO} Sending startgame packet to all clients")

for i, client in enumerate(all_clients):
    client.send("msg.gamestart".encode("utf-8"))

time.sleep(0.1)

print(f"{PREFIX_INFO} Sending question pack to users")
print(f"{PREFIX_INFO} Encoding math questions")
msg_to_send = pickle.dumps(math_questions)
print(f"{PREFIX_INFO} Successfully encoded math questions")

print(f"{PREFIX_INFO} Sending to all clients...")

for i, send_client in enumerate(all_clients):
    try:
        send_client.send(msg_to_send)
    except ConnectionResetError:
        print(f"{PREFIX_WARNING} Could not send data to {all_addresses[i]}: player disconnected")
        print(f"{PREFIX_INFO} Removing {all_addresses[i]} from the player list...")
        del all_clients[i]
        del all_addresses[i]
        del all_usernames[i]
        print(f"{PREFIX_INFO} Only {len(all_clients)} Will be playing in this round!")

for i, client in enumerate(all_clients):
    print(f"{PREFIX_INFO} Preparing score variable for client {all_usernames[i]}")
    all_usernames_scores[all_usernames[i]] = 0

print(f"{PREFIX_INFO} Creating idleTimeout value to each client")
for i, client in enumerate(all_clients):
    time_since_last_packet[client] = 0
    print(f"{PREFIX_INFO} Successfully creating list element #{i}/{len(all_clients)}")
print(f"{PREFIX_INFO} Finished creating timeout values for all clients")

print(f"{PREFIX_INFO} Finished preparing game (took {(round(time.monotonic() * 1000)) - start_time}ms)")

print(f"{PREFIX_INFO} Game started")

while True:
    try:
        while True:

            for i, client in enumerate(all_clients):
                try:
                    msg = client.recv(20480).decode()

                    # Reset inactivity timeout
                    # print(f"{PREFIX_INFO} Player {all_usernames[i]} passed the test!")
                    # print(f"{PREFIX_INFO} Updating new time for inactivity timeout list")

                    # Packet classification

                    if msg == "msg.point":
                        print(f"{PREFIX_GAME} {all_usernames[i]} scored a point")
                        all_usernames_scores.update({all_usernames[i]: all_usernames_scores[all_usernames[i]] + 1})
                        print(f"{PREFIX_GAME} All scores: {all_usernames_scores}")

                        time_since_last_packet[client] = 0

                    elif msg == "msg.getpoints":
                        client.send(pickle.dumps(all_usernames_scores))

                        time_since_last_packet[client] = 0

                    elif msg == "msg.incorrect":
                        print(f"{PREFIX_GAME} {all_usernames[i]} Got a question wrong ans his score was reset")
                        all_usernames_scores.update({all_usernames[i]: 0})
                        print(f"{PREFIX_GAME} All scores: {all_usernames_scores}")

                        time_since_last_packet[client] = 0

                    # Check for idle timeout

                    if time_since_last_packet[client] >= IDLE_TIMEOUT:
                        print(f"{PREFIX_INFO} Player {all_usernames[i]} was kicked due to inactivity ("
                              f"{time_since_last_packet[client]})")
                        del time_since_last_packet[client]
                        del all_clients[i]
                        del all_addresses[i]
                        del all_usernames_scores[all_usernames[i]]
                        del all_usernames[i]

                        if len(all_clients) == 0:
                            print(f"{PREFIX_INFO} There are no players left in the game, shutting down server")
                            a = input("Press ENTER to terminate application")
                            sys.exit()

                        continue

                    time_since_last_packet[client] += 1

                except ConnectionResetError:
                    # Disconnect handler

                    print(f"{PREFIX_INFO} {all_usernames[i]} or {all_addresses[i]} Disconnected!")
                    del time_since_last_packet[all_clients[i]]
                    del all_clients[i]
                    del all_addresses[i]
                    del all_usernames_scores[all_usernames[i]]
                    del all_usernames[i]

                    if len(all_clients) == 0:
                        print(f"{PREFIX_INFO} There are no players left in the game, shutting down server")
                        a = input("Press ENTER to terminate application")
                        sys.exit()

                    continue

                except IOError as e:

                    if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
                        print(f"{PREFIX_ERROR} Reading error: ", str(e))
                        a = input("Press ENTER to terminate application")
                        sys.exit()

                    # Check inactivity time (Specified in config at top of file)
                    # print(f"{PREFIX_INFO} Checking last packet received time for client {all_addresses[i]} Username:"
                    #       f"{all_usernames[i]}")

                    continue

    except IOError as e:
        if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
            print(f"{PREFIX_ERROR} Reading error: ", str(e))
            a = input("Press ENTER to terminate application")
            sys.exit()

        continue
