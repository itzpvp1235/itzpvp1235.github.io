# CLIENT SETTINGS ------------------------

IP = "192.168.56.1"
# Ask your server manager for the IP address for the server

PORT = 12345
# The port number to listen on, make sure that this number
# is the same as the number on the server
#
# IMPORTANT NOTICE: Make sure you have the same IP and PORT
# on both the server and client.

# DEBUGGING ------------------------------

NO_WAIT = False
# When playing, set this value to "False"
# This will bypass the "Waiting for players" screen

# DO NOT EDIT CODE -----------------------
# Please do not edit the code below, if you do, the program may error or malfunction

import socket
import sys
import errno
import pickle
import pygame
import time

game_started = 0
DUMMY_MESSAGE = "asdfaksdfsfjskldfjsdlkfjsdf"

pygame.init()
screen = pygame.display.set_mode((2000, 1000), pygame.RESIZABLE)
pygame.display.init()
pygame.display.set_caption("Math Game!!!!!!!!!!!!!!!")

font = pygame.font.SysFont("Calibri, Arial", 30)

clock = pygame.time.Clock()
FPS = 120

running = True
out_of_loop = False
name = ""
show_pipe = 0

while running:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                running = False

            elif event.key == pygame.K_BACKSPACE:
                if name != "":
                    name = name[0: len(name) - 1]

            else:
                char = pygame.key.name(event.key)

                if len(char) == 1:
                    name += char

    screen.fill((255, 255, 255))

    text = font.render("Enter a name:", True, [0, 0, 0])
    screen.blit(text, [1000 - text.get_rect().width / 2, 500])

    if show_pipe > 50:
        text = font.render(name + "|", False, [0, 0, 0])
        screen.blit(text, [1000 - text.get_rect().width / 2, 600])

    else:
        text = font.render(name + " ", False, [0, 0, 0])
        screen.blit(text, [1000 - text.get_rect().width / 2, 600])

    show_pipe += 1

    if show_pipe == 100:
        show_pipe = 0

    pygame.display.update()

while True:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    try:
        screen.fill((255, 255, 255))
        text = font.render("Connecting to the server...", True, (0, 0, 0))
        screen.blit(text, [1000 - text.get_rect().width / 2, 400])
        pygame.display.update()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((IP, PORT))

        s.send(name.encode('utf-8'))

        break
    except ConnectionRefusedError as e:
        screen.fill((255, 255, 255))

        text = font.render("Failed to connect to server, retrying in 3s", True, (0, 0, 0))
        screen.blit(text, [1000 - text.get_rect().width / 2, 400])
        text = font.render(str(e), True, [0, 0, 0])
        screen.blit(text, [1000 - text.get_rect().width / 2, 500])
        pygame.display.update()
        time.sleep(3)

question_font = pygame.font.SysFont("Calibri, Arial", 70)
answer_font = pygame.font.SysFont("Calibri, Arial", 50)
details_font = pygame.font.SysFont("Calibri, Arial", 20)
running = True
if NO_WAIT:
    firstItter = False
else:
    firstItter = True

current_question = 0
minus = False
answer = ""
unit = 1500
timer = 60
biggest_answer_streak = 0
incorrect_questions = 0
prev_points = {}
game_over = False
end_first_iteration = True

while running:
    clock.tick(FPS)
    if not game_over:
        screen.fill((255, 255, 255))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if not firstItter and not game_over:
                if event.key == pygame.K_1:
                    answer += "1"
                elif event.key == pygame.K_2:
                    answer += "2"
                elif event.key == pygame.K_3:
                    answer += "3"
                elif event.key == pygame.K_4:
                    answer += "4"
                elif event.key == pygame.K_5:
                    answer += "5"
                elif event.key == pygame.K_6:
                    answer += "6"
                elif event.key == pygame.K_7:
                    answer += "7"
                elif event.key == pygame.K_8:
                    answer += "8"
                elif event.key == pygame.K_9:
                    answer += "9"
                elif event.key == pygame.K_0:
                    answer += "0"
                elif event.key == pygame.K_MINUS:
                    if minus:
                        minus = False
                        answer = answer[1: len(answer)]
                    else:
                        minus = True
                        answer = "-" + answer

                elif event.key == pygame.K_BACKSPACE:
                    if answer == "-":
                        minus = False
                    answer = answer[0: len(answer) - 1]

                elif event.key == pygame.K_RETURN:
                    minus = False

                    if answer != "" and answer != "-":
                        if int(answer) == questions_answer[current_question]:
                            answer = ""
                            s.send("msg.point".encode("utf-8"))

                            current_question += 1
                            biggest_answer_streak += 1

                            pygame.display.update()
                            continue
                        else:
                            answer = ""
                            s.send("msg.incorrect".encode("utf-8"))

                            if biggest_answer_streak <= current_question:
                                biggest_answer_streak = current_question

                            current_question = 0
                            incorrect_questions += 1

                            pygame.display.update()
                            minus = False
                            continue

    if firstItter and not game_over:
        try:
            text = font.render("Waiting for players...", False, [0, 0, 0])
            screen.blit(text, [1000 - text.get_rect().width / 2, 500])
            pygame.display.update()

            msg = s.recv(1024).decode("utf-8")

            if msg == DUMMY_MESSAGE:
                s.send(DUMMY_MESSAGE.encode("utf-8"))
                pygame.display.update()
                continue

            elif msg == "msg.gamestart":
                time.sleep(1)
                msg = s.recv(1000000)
                questions = pickle.loads(msg)
                questions_start = list(questions)
                questions_answer = list(questions.values())
                top = 0

                time.sleep(0.05)
                s.send("msg.getpoints".encode("utf-8"))
                points = pickle.loads(s.recv(1000000))

                firstItter = False
                pygame.display.update()

            elif msg == DUMMY_MESSAGE + "msg.gamestart":
                time.sleep(1)
                msg = s.recv(1000000)
                questions = pickle.loads(msg)
                questions_start = list(questions)
                questions_answer = list(questions.values())
                top = 0

                time.sleep(0.05)
                s.send("msg.getpoints".encode("utf-8"))
                points = pickle.loads(s.recv(1000000))

                firstItter = False
                pygame.display.update()

                s.send(DUMMY_MESSAGE.encode("utf-8"))
                pygame.display.update()
                continue

            pygame.display.update()

        except Exception as e:
            if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
                print("Reading error: ", str(e))
                a = input("Press ENTER to terminate application")
                sys.exit()

            text = font.render("Waiting for players...", False, [0, 0, 0])
            screen.blit(text, [1000 - text.get_rect().width / 2, 500])
            pygame.display.update()
            continue

        finally:
            pygame.display.update()

        pygame.display.update()

    else:
        if not game_over:
            # GAME :)

            # Ask server for scores

            if timer >= 60:
                s.send("msg.getpoints".encode("utf-8"))
                for i in range(1, 50):
                    pass

                prev_points = points

                points = s.recv(1000000)
                points = pickle.loads(points)

                points = {k: v for k, v in sorted(points.items(), key=lambda item: item[1])}
                new_dict = {}

                for k, v in points.items():
                    dict_element = {k: v}
                    dict_element.update(new_dict)
                    new_dict = dict_element

                points = new_dict
                top = list(points.values())[0]

                timer = 0
            timer += 1

            if top >= len(questions):
                print("gameover!!!!!")
                game_over = True

            # The game :)

            if NO_WAIT:
                pygame.display.set_caption("Math Game ( DEBUG MODE )")

            # Create question label
            try:
                text = question_font.render(questions_start[current_question] + "=", False, [0, 0, 0])
                screen.blit(text, [400, 120])
            except:
                pass

            # Create separator line between questions and leaderboard
            pygame.draw.line(screen, (0, 0, 0), (0, 200), (2000, 200), 5)

            # Add user info
            text = details_font.render(f"User: {name}  Position #{list(points.keys()).index(name) + 1}/{len(points)}"
                                       f"  Score: {points[name]}  Players: {len(points)}", False, [0, 0, 0])
            screen.blit(text, [10, 10])
            text = details_font.render(f"Server running on port {PORT} and IP {IP}", False, [0, 0, 0])
            screen.blit(text, [10, 30])
            text = font.render(f"Question: {current_question + 1} Correct: {current_question}"
                               f" Incorrect: {incorrect_questions}", False, [0, 0, 0])
            screen.blit(text, [400, 85])

            # Create answer box
            pygame.draw.rect(screen, (220, 220, 255), (900, 120, 800, 70))

            # Create the text that the user typed in the answer box
            text = answer_font.render(answer, False, [0, 0, 0])
            screen.blit(text, [915, 130])

            # LEADERBOARD ------------------

            # Create markers

            unit_count = 1500 // unit
            for i in range(0, unit_count):
                text = font.render(f"{i}", False, [0, 0, 0])
                screen.blit(text, [250 + (i * unit), 170])

            # Creating your position
            text = font.render("You", False, [0, 0, 0])
            screen.blit(text, [30, 215])

            text = font.render(f"#{list(points.keys()).index(name)}|Score: {points[name]}", False, [0, 0, 0])
            screen.blit(text, [30, 250])

            pygame.draw.rect(screen, [255, 0, 0], (250, 215, current_question * unit, 80))

            pygame.draw.line(screen, (0, 0, 0), (0, 300), (2000, 300), 3)

            unit = 1500 // (top + 1)

            if len(points) <= 8:

                for i, user in enumerate(list(points.keys())):
                    text = font.render(f"#{i + 1}: {user}", False, [0, 0, 0])
                    screen.blit(text, [30, 315 + (i * 100)])

                    text = font.render(f"Score: {points[user]} (top {int(points[user] / len(points) * 100)}%)", False,
                                       [0, 0, 0])
                    screen.blit(text, [30, 345 + (i * 100)])

                    if user == name:
                        pygame.draw.rect(screen, [255, 0, 0], (250, 315 + (i * 100), points[user] * unit, 80))
                    else:
                        pygame.draw.rect(screen, [0, 0, 255], (250, 315 + (i * 100), points[user] * unit, 80))

            else:
                for i, user in enumerate(points.keys()[0: 7]):
                    text = font.render(f"#{i + 1}: {user}", False, [0, 0, 0])
                    screen.blit(text, [30, 315 + (i * 100)])

                    text = font.render(f"Score: {points[user]}", False, [0, 0, 0])
                    screen.blit(text, [30, 330 + (i * 100)])

                    if user == name:
                        pygame.draw.rect(screen, [255, 0, 0], (250, 315 + (i * 100), points[user] * unit, 80))
                    else:
                        pygame.draw.rect(screen, [0, 0, 255], (250, 315 + (i * 100), points[user] * unit, 80))

                pygame.display.update()


        # END SCREEN
        else:
            screen.fill((255, 255, 255))

            if end_first_iteration:
                for i in range(0, 201):
                    end_text = question_font.render("GAME OVER", False, [0, 0, 0])
                    screen.blit(end_text, [1000 - end_text.get_rect().width / 2, i])

                    pygame.display.update()
                    screen.fill((255, 255, 255))
            else:
                end_text = question_font.render("GAME OVER", False, [0, 0, 0])
                screen.blit(end_text, [1000 - end_text.get_rect().width / 2, 200])

            unit_end_screen = 700 // top

            if len(points) <= 20:
                for i, user in enumerate(list(points.keys())[0: 19]):

                    if user == name:

                        if end_first_iteration:
                            for j in range(1, points[user] * unit_end_screen):
                                pygame.draw.rect(screen, [255, 0, 0], (i * 85, (1000 - j) - (points[user] *
                                                                                             unit_end_screen),
                                                                       80, points[user] * unit_end_screen))
                                pygame.display.update()

                            end_first_iteration = False
                            continue
                        else:
                            pygame.draw.rect(screen, [255, 0, 0], (i * 85, 1000 - (points[user] * unit_end_screen),
                                                                   80, points[user] * unit_end_screen))

                        text = question_font.render(f"{points[user]}", False, [0, 0, 0])
                        screen.blit(text, (
                            (i * 80) + (80 - text.get_rect().width / 2), 930 - (points[user] * unit_end_screen)))
                    else:

                        if end_first_iteration:
                            for j in range(1, points[user] * unit_end_screen):
                                pygame.draw.rect(screen, [0, 0, 255], (i * 85, (1000 - j) - (points[user] *
                                                                                             unit_end_screen),
                                                                       80, points[user] * unit_end_screen))
                                pygame.display.update()

                            end_first_iteration = False
                            continue
                        else:
                            pygame.draw.rect(screen, [0, 0, 255], (i * 85, 1000 - (points[user] * unit_end_screen),
                                                                   80, points[user] * unit_end_screen))

                        text = question_font.render(f"{points[user]}", False, [0, 0, 0])
                        screen.blit(text, (
                            (i * 80) + (80 - text.get_rect().width / 2), 930 - (points[user] * unit_end_screen)))

            else:
                for i, user in enumerate(list(points.keys()[0: 19])):

                    if user == name:

                        if end_first_iteration:
                            for j in range(1, points[user] * unit_end_screen):
                                pygame.draw.rect(screen, [255, 0, 0], (i * 85, (1000 - j) - (points[user] *
                                                                                             unit_end_screen),
                                                                       80, points[user] * unit_end_screen))
                                pygame.display.update()

                            end_first_iteration = False
                            continue
                        else:
                            pygame.draw.rect(screen, [255, 0, 0], (i * 85, 1000 - (points[user] * unit_end_screen),
                                                                   80, points[user] * unit_end_screen))

                        text = question_font.render(f"{points[user]}", False, [0, 0, 0])
                        screen.blit(text, (
                            (i * 80) + (80 - text.get_rect().width / 2), 930 - (points[user] * unit_end_screen)))
                    else:

                        if end_first_iteration:
                            for j in range(1, points[user] * unit_end_screen):
                                pygame.draw.rect(screen, [0, 0, 255], (i * 85, (1000 - j) - (points[user] *
                                                                                             unit_end_screen),
                                                                       80, points[user] * unit_end_screen))
                                pygame.display.update()

                            end_first_iteration = False
                            continue
                        else:
                            pygame.draw.rect(screen, [0, 0, 255], (i * 85, 1000 - (points[user] * unit_end_screen),
                                                                   80, points[user] * unit_end_screen))

                        text = question_font.render(f"{points[user]}", False, [0, 0, 0])
                        screen.blit(text, (
                            (i * 80) + (80 - text.get_rect().width / 2), 930 - (points[user] * unit_end_screen)))

            pygame.display.update()

    pygame.display.update()

# GAMEOVER SCREEN

# while game_over:
#
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             game_over = False
#             continue
#
