with open("words_one.txt", "r") as f:
    words = f.read().split("\n")


def check_message(message=None):
    spam_prob = 0
    remove_words = 0

    message = message.split(" ")

    one_letter_words = 0

    for i in message:
        if len(i) == 0:
            one_letter_words += 1

    if one_letter_words >= ((len(message) * 2) // 3):
        print(one_letter_words)
        return True

    for word in message:
        for letter in word:
            if letter not in list("abcdefghijklmnopqrstuvwxyz"):
                remove_words -= 1
                continue

        if word in words:
            spam_prob += 1

    spam_prob = spam_prob / (len(message) - remove_words)

    return spam_prob < 0.7

print(check_message("test test test test test test test"))