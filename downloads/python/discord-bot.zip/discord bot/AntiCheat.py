import discord
from discord.ext import commands
from discord.ext.commands import CommandNotFound
from discord.ext.commands import BadArgument

print("Bot is starting")

client = commands.Bot(command_prefix="!")

print("Reading in words file")

with open("words_one.txt", "r") as f:
    global words
    words = f.read().split("\n")

with open("whitelisted_words.txt", "r") as f:
    global whitelisted_words
    whitelisted_words = f.read().split("\n")

prev_msgs = {}


def check_message(message=None, user=None):
    spam_prob = 0
    remove_words = 0

    message = message.lower()

    if message in whitelisted_words:
        return False

    if user in prev_msgs.keys():
        if prev_msgs[user] == message:
            return True, "MultiSpamMessage"
        else:
            prev_msgs[user] = message
    else:
        prev_msgs[user] = message

    if len(message) <= 2:
        return True, "MessageTooShort"

    message = message.split(" ")

    same_words = 0
    used_words = []

    if message[-1][-1] not in list("abcdefghijklmnopqrstuvwxyz"):
        return False

    if len(message) > 3:
        for i in message:
            if i in used_words:
                same_words += 1
            else:
                used_words.append(i)

        if same_words >= (len(message) * 2 // 3):
            return True, "SimelarWord"

    for word in message:
        for letter in word:
            if letter not in list("abcdefghijklmnopqrstuvwxyz"):
                remove_words -= 1
                continue

        if word in words:
            spam_prob += 1

    spam_prob = spam_prob / (len(message) - remove_words)

    return spam_prob < 0.85, "ToLittleWords"


@client.event
async def on_ready():
    await client.change_presence(status=discord.Status.online, activity=discord.Game("Vibin'"))
    print("Bot online")


@client.event
async def on_member_join(member):
    print(f"New member joined: {member}")
    with open("user_vl.csv", "a") as write_F:
        write_F.write(f"\n{member},0")
    print("Successfully added member to database")


@client.event
async def on_member_remove(member):
    print(f"Member left server: {member}")
    with open("user_vl.csv", "r") as read_f:
        file_contents = read_f.read()

    users = file_contents.split("\n")
    for i, user in enumerate(users):
        if user.split(",")[0] == str(member):
            del users[i]
            break

    final_str = ""
    for line in users:
        final_str += f"{line}\n"

    with open("user_vl.csv", "w") as write_f:
        write_f.write(final_str)


@client.event
async def on_message(ctx):
    try:
        if str(ctx.channel) == "general":
            if ctx.clean_content[0] != "!" and ctx.clean_content[0] != "@" and (str(ctx.author) != "yay yay yay#7853"):
                res, flg = check_message(ctx.clean_content, str(ctx.author))
                if res:
                    with open("user_vl.csv", "r") as f:
                        contents = f.read().split("\n")

                    contents_new = ""

                    for i in contents:
                        if i.split(",")[0] != str(ctx.author):
                            contents_new += i
                        else:
                            value = int(i.split(",")[1])
                            value += 1
                            string = i.split(",")[0] + "," + str(value)
                            contents_new += string
                        contents_new += "\n"

                    with open("user_vl.csv", "w") as f:
                        f.write(contents_new)

                    print(f"Message \"{ctx.clean_content}\" from {ctx.author} was marked as spam. Flagged by {flg}")
                    await ctx.channel.purge(limit=1)
                else:
                    await client.process_commands(ctx)
            else:
                await client.process_commands(ctx)
    except:
        pass


@client.command(name="test", aliases=["checkvl", "checkuser", "cvl", "vl"])
async def check_vl(ctx, question: discord.Member):
    print(f"{ctx.author} Requested to access violation level of {question}")
    with open("user_vl.csv", "r") as read_f:
        user_rep = read_f.read().split("\n")

        found = False

        for i in user_rep:
            if i.split(",")[0] == str(question):
                get_user = i.split(",")[1]
                found = True
                break

        if found:
            await ctx.send(f"""Violation levels for {question}: {get_user}""")
        else:
            await ctx.send(f"""Could not find {question} in the database :(""")


@client.event
async def on_command_error(ctx, error):
    if isinstance(error, CommandNotFound):
        await ctx.send("Command not found!")
        print(str(ctx.author) + " requested an invalid command: " + str(ctx.clean_content))
    elif isinstance(error, BadArgument):
        await ctx.send("Bad argument!")
    else:
        raise error


client.run("Add your discord token here")
