# Importing
import time
import random
import os

# Code

print("LightOS setup")
print("--------------------\n")

print("Please make sure that the settings for the OS is correct.")

Language = "English - US"
keyboard = "US-QWERTY"

while True:
    settings = input("Language: " + Language + "\n\
Keyboard layout: " + keyboard + "\n\
\n\
Please choose one of the options below:\n\
A: These settings are correct, continue\n\
B: One or both of the settings are not correct\n")

    settings = settings.upper()

    if settings == "A":
        print("\nPlease wait, setup is loading")
        correctSettings = True
        break

    elif settings == "B":
        settingsChange = input("Please enter what setting you want to change\n\
    A: Language\n\
    B: Keyboard\n")
        settingsChange = settingsChange.upper()
        if settingsChange == "A":
            print("Please waint, loading countries\n")

            countrySet = input("""Please select your coutry from the list below:

    A: English (US)
    B: English (UK)
    C: English (Canada)
    D: Chinese (Simplified)
    E: Chinese (Triditional)
    F: Japanese

    Please note that Chinese translations may not be 100% Accurate!!!
    Please note that while the OS will be in the selected langugae above, the setup will be in english!
    """)

            countrySet = countrySet.upper()
            if countrySet == "A":
                Language = "English - US"
            elif countrySet == "B":
                Language = "English - UK"
            elif countrySet == "C":
                Language = "English - Canadian"
            elif countrySet == "D":
                Language = "Simplified chinese"
            elif countrySet == "E":
                Language = "Traditional chinese"
            elif countrySet == "F":
                Language = "Japanese"
            continue

        elif settingsChange == "B":
            print("Please wait, loading Keyboard layouts\n")
            print("Sorry, keyboard layouts are not implementerd yet in this update of LightOS.\n\n\n\nx")

if correctSettings:
    print("Please wait, loading files with GUI Mode, this may take a while...")

    print("0% Complete")

    setupGUI1 = ("""
+------------------------------------+
|                                    |
|Light OS setup                      |
|Please press ENTER to start part 1  |
|of the setup.                       |
|                                    |
|Part 1 of the setup woll collect    |
|information from the usre to install|
|the correct version of LightOS.     |
|                                    |
|Please do not exit the setup while  |
|the installer is copying files, if  |
|you do, LightOS may be corrupted or |
|completely missing. If you do exit  |
|the setup, open the setup again and |
|select the "Remove LightOS, then run|
|the setup again.                    |
+------------------------------------+""")

    print("50% Complete")
    setupGUI2 = "Please type the password\n>"

    print("100% Complete")

    setupStart = input(setupGUI1)
    os.system("cls")

    if setupStart == "":
        setupAgreement = input(setupGUI2)
        setupAgreement = setupAgreement.upper()
        os.system("cls")

        if setupAgreement == "123":
            setupWriteFunction = input("""
+-----------------------------------------+
|Setup is about to start writing functions|
|                                         |
|Press ENTER to start                     |
+-----------------------------------------+""")

            os.system("cls")

            def progressBar(number, totalnumber):
                char = "█"
                empty = " "
                progress = char * number

                while len(progress) < totalnumber:
                    progress = progress + empty

                finishedBar = "[" + progress + "]"
                print(finishedBar)


            SetupWriteFunctionFinished = input("""
+-----------------------------------------+
|setup is now complete writing functions  |
|                                         |
|Press ENTER to finish                    |
+-----------------------------------------+""")

            os.system("cls")

            setupInstallationPart2 = input("""
+-----------------------------------------+
|Setup is about to start creating system  |
|files                                    |
|Press ENTER to start                     |
+-----------------------------------------+""")

            os.system("cls")

            fileName = ""
            while fileName == "":
                fileName = input("Enter the file name that you want your os to be installed in\n> ")

            os.system("cls")

            print("Preparing to install lightOS, please wait...")
            print("Please do not close installer")
            
            os.system("cls")

            with open("oscopy.txt", "r") as f:
                contents = f.read()

            with open(fileName+ ".py", "a") as f:
                count = 1
                for line in contents.splitlines():
                    print("Installing lightOS, please wait...")
                    print("Please do not close installer")
                    print(f"                                     {count}% complete")
                    progressBar(count, 100)

                    f.write(line)
                    f.write("\n")

                    os.system("cls")
                    count+= 1


            print("LightOS has been successfully installed on your computer!")
            print("Thanks for installing lightOS!")
            input("Press ENTER to exit the setup!")

        else:
            input("The password you entered is incorrect, press enter to exit the program!")
